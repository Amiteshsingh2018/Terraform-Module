#!/bin/bash
cd ${DEPLOY_HOME}/terraform
terraform init \
-backend=true -backend-config="access_key=${TF_VAR_access_key}" \
-backend-config="secret_key=${TF_VAR_secret_key}" \
-backend-config="bucket=${TF_backend_s3_bucket}" \
-backend-config="key=${TF_VAR_project}"
if !(terraform workspace select ${TF_VAR_backend_key}-tfstate ); then (exit) fi
terraform destroy -auto-approve ${TF_DESTROY_OPTIONS}